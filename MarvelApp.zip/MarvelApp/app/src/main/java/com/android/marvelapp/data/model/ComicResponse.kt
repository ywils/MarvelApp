package com.android.marvelapp.data.model


import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ComicResponse(
    @Json(name = "code")
    val code: Int,
    @Json(name = "status")
    val status: String,
    @Json(name = "copyright")
    val copyright: String,
    @Json(name = "attributionText")
    val attributionText: String,
    @Json(name = "attributionHTML")
    val attributionHTML: String,
    @Json(name = "etag")
    val etag: String,
    @Json(name = "data")
    val data: Data
)

@JsonClass(generateAdapter = true)
data class Data(
    @Json(name = "offset")
    val offset: Int,
    @Json(name = "limit")
    val limit: Int,
    @Json(name = "total")
    val total: Int,
    @Json(name = "count")
    val count: Int,
    @Json(name = "results")
    val results: List<Result>
)

@JsonClass(generateAdapter = true)
data class Result(
    @Json(name = "id")
    val id: Int,
    @Json(name = "digitalId")
    val digitalId: Int,
    @Json(name = "title")
    val title: String,
    @Json(name = "issueNumber")
    val issueNumber: Int,
    @Json(name = "variantDescription")
    val variantDescription: String,
    @Json(name = "description")
    val description: String?,
    @Json(name = "modified")
    val modified: String,
    @Json(name = "isbn")
    val isbn: String,
    @Json(name = "upc")
    val upc: String,
    @Json(name = "diamondCode")
    val diamondCode: String,
    @Json(name = "ean")
    val ean: String,
    @Json(name = "issn")
    val issn: String,
    @Json(name = "format")
    val format: String,
    @Json(name = "pageCount")
    val pageCount: Int,
    @Json(name = "textObjects")
    val textObjects: List<Any>,
    @Json(name = "resourceURI")
    val resourceURI: String,
    @Json(name = "urls")
    val urls: List<Url>,
    @Json(name = "series")
    val series: Series,
    @Json(name = "variants")
    val variants: List<Variant>,
    @Json(name = "collections")
    val collections: List<Any>,
    @Json(name = "collectedIssues")
    val collectedIssues: List<Any>,
    @Json(name = "dates")
    val dates: List<Date>,
    @Json(name = "prices")
    val prices: List<Price>,
    @Json(name = "thumbnail")
    val thumbnail: Thumbnail,
    @Json(name = "images")
    val images: List<Any>,
    @Json(name = "creators")
    val creators: Creators,
    @Json(name = "characters")
    val characters: Characters,
    @Json(name = "stories")
    val stories: Stories
)

@JsonClass(generateAdapter = true)
data class Url(
    @Json(name = "type")
    val type: String,
    @Json(name = "url")
    val url: String
)

@JsonClass(generateAdapter = true)
data class Series(
    @Json(name = "resourceURI")
    val resourceURI: String,
    @Json(name = "name")
    val name: String
)

@JsonClass(generateAdapter = true)
data class Variant(
    @Json(name = "resourceURI")
    val resourceURI: String,
    @Json(name = "name")
    val name: String
)

@JsonClass(generateAdapter = true)
data class Date(
    @Json(name = "type")
    val type: String,
    @Json(name = "date")
    val date: String
)

@JsonClass(generateAdapter = true)
data class Price(
    @Json(name = "type")
    val type: String,
    @Json(name = "price")
    val price: Double
)

@JsonClass(generateAdapter = true)
data class Thumbnail(
    @Json(name = "path")
    val path: String,
    @Json(name = "extension")
    val extension: String
)

@JsonClass(generateAdapter = true)
data class Creators(
    @Json(name = "available")
    val available: Int,
    @Json(name = "collectionURI")
    val collectionURI: String,
    @Json(name = "items")
    val items: List<Item>,
    @Json(name = "returned")
    val returned: Int
)

@JsonClass(generateAdapter = true)
data class Item(
    @Json(name = "resourceURI")
    val resourceURI: String,
    @Json(name = "name")
    val name: String,
    @Json(name = "role")
    val role: String
)


@JsonClass(generateAdapter = true)
data class Characters(
    @Json(name = "available")
    val available: Int,
    @Json(name = "collectionURI")
    val collectionURI: String,
    @Json(name = "items")
    val items: List<Any>,
    @Json(name = "returned")
    val returned: Int
)

@JsonClass(generateAdapter = true)
data class Stories(
    @Json(name = "available")
    val available: Int,
    @Json(name = "collectionURI")
    val collectionURI: String,
    @Json(name = "items")
    val items: List<Item>,
    @Json(name = "returned")
    val returned: Int
)
