package com.android.marvelapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.android.marvelapp.data.model.Result
import com.android.marvelapp.data.network.Resource
import com.android.marvelapp.databinding.ActivityMainBinding
import com.android.marvelapp.ui.ComicViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val viewModel: ComicViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        startObservers()
    }

    private fun startObservers() {
        viewModel.comics.observe(this) { resource ->
            when (resource) {
                is Resource.Success -> {
                    setView(resource.data)
                }
                is Resource.Loading -> {}

                is Resource.Error -> {}
            }


        }

        viewModel.spinner.observe(this) { res ->
            binding.prog.visibility = if (res) View.VISIBLE else View.GONE
        }
    }

    private fun setView(result: Result) {
        binding.comicTitle.text = result.title
        binding.comicDsc.text = result.description ?: "No description available"
        Glide.with(binding.root.context)
            .load(result.thumbnail.path)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .apply(
                RequestOptions()
                    .error(R.drawable.ic_baseline_error_24)
                    .placeholder(R.drawable.ic_baseline_image_24)
                    .fitCenter()
            )
            .into(binding.mainImage)

        Glide.with(binding.root.context)
            .load(result.thumbnail.path)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .apply(
                RequestOptions()
                    .error(R.drawable.ic_baseline_error_24)
                    .placeholder(R.drawable.ic_baseline_image_24)
                    .fitCenter()
            )
            .into(binding.baseImage)
    }
}