package com.android.marvelapp

object Constants {

    const val PRIVATE_KEY = "897805caa24e1ed8bdeb3a45513febe9252140a3"
    const val PUBLIC_KEY = "abc11ecdbd710c7541eca0ea6d9361d8"
}